
const help = (prefix) ={
                return'
┏━━━━━━━━━━®¥ * MENU BOT * ¥®~~~~~~
┣━⊱ ❉ #tts id 
┣━⊱ ❉ #block [@]
┣━⊱ ❉ #randomanime
┣━⊱ ❉ #nekonime
┣━⊱ ❉ #pokemon
┣━⊱ ❉ #bucin
┣━⊱ ❉ #sticker
┣━⊱ ❉ #kick[@]
┣━⊱ ❉ #add[nomer]